import os
from calibrar_cam import calibrarCam
from identifyQR import identificacion
from detectQR import detectionQR
from distanceObj import distance
from AngleObj import angle

# Accedemos a los tests de nuestros QR
carpetaAct = os.getcwd()
images = os.listdir(carpetaAct + '/test')

#for iter in range(len(images)):
for iter in range(1):
    # Calibramos la imagen para poder obtener la distancia entre la captura y el QR
    ret, mtx, dist, rvecs, tvecs = calibrarCam()

    # Detectamos el QR y lo decodificamos obteniendo la zona a la que representa
    decoded, sizeTotal, sizeQR, centralPoint = detectionQR(images[2])
    print('El mensaje descodificado ha sido: ' + str(decoded))
    print('El size total de imagen es de: ' + str(sizeTotal))
    print('El size en filas, de nuestro QR en pixeles es de: ' + str(sizeQR))

    # Miramos si el QR coincide con alguno almacenado a la Base de Datos
    encontrado, iterQR = identificacion(decoded)

    # Deteccion de error
    if encontrado == False:
        print('El QR decodificado no coincide con la Base de Datos')
    else:
        distmetros = distance(mtx, sizeTotal, sizeQR)
        angles = angle(mtx, sizeTotal, centralPoint)
        print('Distancia entre camara y objeto: ' + str(distmetros) + ' metros')
        print('Angulo entre camara y objeto: ' + str(angles) + ' grados')
        print('El QR decodificado coincide con el elemento ' + str(iterQR) + ' de nuestra BBDD')






