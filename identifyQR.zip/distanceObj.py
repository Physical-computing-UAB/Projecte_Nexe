def distance(mtx, sizeTotal, sizeQR):
    #Focal camara utilizada
    focal = 4.077

    distMM = (focal*110*sizeTotal[0]/(sizeQR*28))/100
    return distMM

