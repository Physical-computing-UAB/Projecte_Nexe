from math import *
def angle(rotation, sizeTotal, centralPoint):
    #predeterminado = 72
    #percentage = ((centralPoint)/float(sizeTotal[1]))
    #angleF = (predeterminado*percentage)-predeterminado/2

    x = (sizeTotal[0]/2)-centralPoint[0]
    y = centralPoint[1]
    z = sqrt(x**2 + y**2)
    value = acos(x/z)
    angleF = degrees(value)
    return angleF

