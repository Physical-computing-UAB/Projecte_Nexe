from PIL import Image, ImageDraw
from pyzbar.pyzbar import decode
import os

def detectionQR(imageInicial):
    # Obtenemos la imagen inicial, la convertimos a RGB y creamos una imagen nueva sobre la cual dibujar
    image = Image.open('test/'+imageInicial).convert('RGB')
    size = image.size
    draw = ImageDraw.Draw(image)
    centralPoint = []

    # Para cada QR detectado, lo enmarcamos y lo decodificamos
    for barcode in decode(image):
        rect = barcode.rect
        draw.rectangle(
            (
                (rect.left, rect.top),
                (rect.left + rect.width, rect.top + rect.height)
            ),
            outline='#0080ff'
        )
        draw.polygon(barcode.polygon, outline='#e945ff')
        message = barcode.data
    #image.save('image1.png')
    #prueba = image.crop((rect.left, rect.top, rect.left+rect.width+1, rect.top + rect.height+1))
    #prueba.save('prueba.png')
    centralPoint.append(rect.left + rect.width/2)
    centralPoint.append(rect.top + rect.height/2)

    return message, size, rect.width, centralPoint