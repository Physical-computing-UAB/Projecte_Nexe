import numpy as np
import cv2
import glob
import os

def identificacion(decode):
    # Conseguimos directorio actual, para obtener QR de base de datos
    carpetaAct = os.getcwd()
    images = os.listdir(carpetaAct + '/QR')

    #Obtenemos la extension de nuestras imagenes
    prueba = images[0]
    cont = 0
    for letter in prueba:
        if letter == '.' and cont == 0:
            cont += 1
        if cont != 0:
            cont += 1

    # Conseguimos el nombre de nuestra codificacion
    for elem in range(len(images)):
        images[elem] = os.path.basename(images[elem]).lower()[0:-cont+1]

    # Identificamos si la descodificacion coincide con un elemento de nuestra BBDD
    i=0
    encontrado = False
    while i < range(len(images)) and encontrado == False:
        value = images[i]
        if(decode.lower() == images[i]):
            encontrado = True
        i = i+1
    return encontrado, i


